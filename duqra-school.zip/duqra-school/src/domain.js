export const components = [ ['first','امتحان أول',30],['participation','مشاركة',5],['behavior','سلوك',5],['quizzes','كويزات',5],['homework','واجبات',5],['practical','عملي',10],['final','نهائي',40] ];
export const blankMarks = () => Object.fromEntries(components.map(([k])=>[k,null]));
export function validateMarks(m){
 if(!m || Object.keys(m).length!==components.length) throw Error('بنية العلامات غير صحيحة');
 for(const [key,label,max] of components) if(m[key]!==null && (typeof m[key]!=='number'||!Number.isFinite(m[key])||m[key]<0||m[key]>max)) throw Error(`${label}: أدخل علامة بين 0 و${max}`);
 return m;
}
export function result(m){ validateMarks(m); const values=components.map(([k])=>m[k]); const complete=values.every(v=>v!==null); const total=Math.round(values.reduce((s,v)=>s+(v??0),0)*100)/100; return {total,complete,passed:complete?total>=50:null,coursework:components.slice(1,6).reduce((s,[k])=>s+(m[k]??0),0)}; }
export function stats(rows){ const completed=rows.map(r=>result(r.marks)).filter(r=>r.complete); const passed=completed.filter(r=>r.passed).length; return {count:rows.length,completed:completed.length,incomplete:rows.length-completed.length,passed,failed:completed.length-passed,rate:completed.length?passed/completed.length*100:null,average:completed.length?completed.reduce((s,r)=>s+r.total,0)/completed.length:null}; }
export function rankClasses(classes,rows){return classes.map(c=>({...c,...stats(rows.filter(r=>r.classId===c.id))})).sort((a,b)=>(b.rate??-1)-(a.rate??-1)||(b.average??-1)-(a.average??-1));}
export const normalizeName = s=>s.normalize('NFKC').replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/\s+/g,' ').trim();
export function candidatesFromLines(lines){return lines.map((line,i)=>{ const name=normalizeName(line.replace(/^[\d٠-٩۰-۹\s.\-–()]+/,'').replace(/[\d٠-٩۰-۹]+$/,'')); const valid=/^[\p{Script=Arabic}\s]+$/u.test(name)&&name.split(' ').length>=3; return {id:i,name,selected:false,valid,reason:valid?'راجع الاسم وترتيبه بصريًا مع الأصل':'يحتاج تصحيحًا يدويًا؛ قد يكون عنوانًا أو رقمًا'}; }).filter(r=>r.name);}
export function uniqueNames(names){const set=new Set();return names.map(normalizeName).map(n=>{if(!n||n.length>160||!/[\p{L}]/u.test(n))throw Error('اسم فارغ أو غير صالح');if(set.has(n))throw Error(`اسم مكرر: ${n}`);set.add(n);return n;});}
