// Firebase web configuration is public project metadata, never an Admin SDK key.
// Populated after the private school project is provisioned.
export const cloudSettings={enabled:true,firebase:{apiKey:'AIzaSyDzBYWLQRex8uZUl-3z1hpzGlaZ3AjTE-A',authDomain:'duqra-digital-skills.firebaseapp.com',projectId:'duqra-digital-skills',appId:'1:1010379155903:web:f28ebfa289bbe5471c190a'}};

