import {doc,runTransaction,serverTimestamp,onSnapshot} from 'firebase/firestore';
import {emptySchool,validateBackup} from './personal-store.js';
const CHUNK_SIZE=240000,MAX_PARTS=8;
export function createCloudStorage(db,uid){
 const meta=doc(db,'personalSchools',uid);
 const part=i=>doc(db,'personalSchools',uid,'chunks',String(i));
 async function readIn(tx){const snapshot=await tx.get(meta);if(!snapshot.exists())return{data:emptySchool(),revision:0};const m=snapshot.data();if(!Number.isInteger(m.parts)||m.parts<1||m.parts>MAX_PARTS)throw Error('بنية البيانات السحابية غير صحيحة.');const parts=[];for(let i=0;i<m.parts;i++){const s=await tx.get(part(i));if(!s.exists()||s.data().revision!==m.revision)throw Error('تعذرت قراءة نسخة سحابية متكاملة. أعد المحاولة.');parts.push(s.data().payload);}const data=JSON.parse(parts.join(''));validateBackup({format:'duqra-personal-backup',schemaVersion:1,data});data.revision=m.revision;return{data,revision:m.revision};}
 return{
  async read(){return runTransaction(db,async tx=>(await readIn(tx)).data);},
  async change(change){return runTransaction(db,async tx=>{const previous=await readIn(tx);const next=change(previous.data);next.revision=previous.revision+1;validateBackup({format:'duqra-personal-backup',schemaVersion:1,data:next});const serialized=JSON.stringify(next);const count=Math.ceil(serialized.length/CHUNK_SIZE);if(count>MAX_PARTS)throw Error('حجم البيانات تجاوز سعة النسخة الحالية؛ نزّل نسخة احتياطية وتواصل لتوسيع التخزين. لم يُحذف شيء.');for(let i=0;i<count;i++)tx.set(part(i),{index:i,revision:next.revision,payload:serialized.slice(i*CHUNK_SIZE,(i+1)*CHUNK_SIZE),updatedAt:serverTimestamp()});tx.set(meta,{revision:next.revision,parts:count,updatedAt:serverTimestamp()});return next;});},
  subscribe(onChange,onError){return onSnapshot(meta,{includeMetadataChanges:true},s=>{if(s.exists()&&!s.metadata.hasPendingWrites)onChange(s.data().revision,s.metadata.fromCache);},onError);}
 };
}
