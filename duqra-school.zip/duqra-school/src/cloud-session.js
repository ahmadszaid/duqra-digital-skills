import {initializeApp} from 'firebase/app';
import {getAuth,GoogleAuthProvider,onAuthStateChanged,setPersistence,browserSessionPersistence,signInWithPopup,signOut} from 'firebase/auth';
import {getFirestore} from 'firebase/firestore';
import {createCloudStorage} from './cloud-store.js';
let auth,db;
export async function initializeCloud(config,onUser){const app=initializeApp(config,'personal-school-sync');auth=getAuth(app);db=getFirestore(app);await setPersistence(auth,browserSessionPersistence);return onAuthStateChanged(auth,async user=>{await onUser(user,user?createCloudStorage(db,user.uid):null);});}
export async function signIn(){const provider=new GoogleAuthProvider();provider.setCustomParameters({prompt:'select_account'});return signInWithPopup(auth,provider);}
export const signOutCloud=()=>signOut(auth);
