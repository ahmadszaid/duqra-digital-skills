import {uniqueNames} from './domain.js';
export const SCHOOL_SUBJECT='المهارات الرقمية';
export function validateRosterPackage(data){
 if(!data||data.schemaVersion!==1||data.subject!==SCHOOL_SUBJECT||!Array.isArray(data.classes)||!data.classes.length||data.classes.length>100)throw Error('حزمة الطلاب غير صالحة أو ليست لمادة المهارات الرقمية.');
 const ids=new Set();let total=0;
 for(const c of data.classes){
  if(!/^[a-z0-9-]{2,60}$/.test(c.id)||ids.has(c.id)||typeof c.name!=='string'||c.name.length<2||c.name.length>80||!Array.isArray(c.students)||c.students.length>200)throw Error('تحقق من بيانات الصفوف والشعب.');
  ids.add(c.id);uniqueNames(c.students.map(s=>s.name));const studentIds=new Set();
  for(const s of c.students){if(!/^s[0-9]{3}$/.test(s.id)||studentIds.has(s.id)||!Number.isInteger(s.sourceRow)||s.sourceRow<1||s.name!==s.name.trim())throw Error('معرّف طالب أو ترتيب غير صالح.');studentIds.add(s.id);}
  total+=c.students.length;
 }
 if(data.studentCount!==total)throw Error('عدد الطلاب في الحزمة لا يطابق محتوياتها.');
 return data;
}
