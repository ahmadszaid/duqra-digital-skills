import {gsap} from 'gsap';
import {ScrollTrigger} from 'gsap/ScrollTrigger';
gsap.registerPlugin(ScrollTrigger);
const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');
let paused=localStorage.getItem('duqra-motion')==='paused';
let context,observer,cleanupListeners,frame=0,stage,ctx,width=0,height=0,last=0;
let uniforms={shape:0,intensity:1,pointerX:0,pointerY:0,scroll:0};
const shapes={grades:0,reports:1,import:2,audit:3,settings:4};
const particles=Array.from({length:2200},(_,i)=>({angle:i*2.39996323,radius:.43+Math.sqrt((i*.618033989)%1)*.57,depth:Math.sin(i*1.731),brightness:.2+((i*37)%100)/125}));
export const motionEnabled=()=>!paused&&!reduced.matches;
export function toggleMotion(){paused=!paused;localStorage.setItem('duqra-motion',paused?'paused':'running');refreshMotion();return paused;}
function resize(){width=innerWidth;height=innerHeight;if(!stage)return;const dpr=Math.min(devicePixelRatio||1,1.5);stage.width=width*dpr;stage.height=height*dpr;stage.style.width=width+'px';stage.style.height=height+'px';ctx.setTransform(dpr,0,0,dpr,0,0);draw(last||performance.now(),true);}
function ensureStage(){if(stage)return;stage=document.createElement('canvas');stage.id='ambient-iris';stage.setAttribute('aria-hidden','true');document.body.prepend(stage);ctx=stage.getContext('2d',{alpha:true});if(!ctx){stage.remove();stage=null;return;}addEventListener('resize',resize,{passive:true});addEventListener('pointermove',e=>{uniforms.pointerX=(e.clientX/innerWidth-.5)*18;uniforms.pointerY=(e.clientY/innerHeight-.5)*12;},{passive:true});addEventListener('scroll',()=>uniforms.scroll=scrollY,{passive:true});document.addEventListener('visibilitychange',refreshMotion);reduced.addEventListener('change',()=>{refreshMotion();installViewMotion(document.querySelector('#app'));});resize();refreshMotion();}
function draw(time,still=false){if(!ctx)return;ctx.clearRect(0,0,width,height);const mobile=width<700;const x=mobile?width*.18:width*.18;const y=mobile?210:255;const radius=mobile?180:Math.min(width*.23,320);const t=motionEnabled()&&!still?time*.00012:0;const shift=uniforms.shape;const light=!document.documentElement.classList.contains('dark');const count=mobile?760:particles.length;ctx.globalAlpha=light?.48:.9;for(let i=0;i<count;i++){const p=particles[i];const a=p.angle+t*.12;const wave=Math.sin(a*7+t*2+p.depth)*5;const r=radius*p.radius+wave;const stretch=1+Math.sin(shift*Math.PI/2)*.17;const px=x+Math.cos(a)*r*stretch+uniforms.pointerX*p.depth;const py=y+Math.sin(a)*(r*.8+Math.sin(shift+a*3)*10)+uniforms.pointerY*p.depth-Math.min(uniforms.scroll*.035,45);const dust=Math.sin(i*97.13+t*.4);ctx.fillStyle=light?`rgba(34,100,150,${p.brightness*.48})`:`rgba(${115+Math.round(p.brightness*100)},${170+Math.round(p.brightness*60)},255,${p.brightness*.48})`;const size=i%11===0?1.25:.65;ctx.fillRect(px,py,size,size);if(i%7===0){ctx.strokeStyle=light?'rgba(40,105,160,.14)':'rgba(139,209,255,.14)';ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(px+Math.cos(a)*(.5+dust*2),py+Math.sin(a)*(.5+dust*2));ctx.stroke();}}
ctx.globalAlpha=light?.2:.35;ctx.strokeStyle=light?'#4d83a4':'#8ec9e9';ctx.lineWidth=.5;for(let i=0;i<3;i++){ctx.beginPath();ctx.ellipse(x,y-Math.min(uniforms.scroll*.035,45),radius*(.42+i*.028),radius*(.34+i*.026),Math.sin(shift)*.1,0,Math.PI*2);ctx.stroke();}ctx.globalAlpha=1;if(!still&&motionEnabled()&&!document.hidden)frame=requestAnimationFrame(loop);}
function loop(time){if(time-last<32){frame=requestAnimationFrame(loop);return;}last=time;draw(time);}
function refreshMotion(){cancelAnimationFrame(frame);if(!stage)return;if(motionEnabled()&&!document.hidden)frame=requestAnimationFrame(loop);else draw(last||performance.now(),true);document.documentElement.dataset.motion=motionEnabled()?'running':'paused';}
export function installViewMotion(root,view='grades'){
 context?.revert();observer?.disconnect();cleanupListeners?.();ensureStage();
 const button=root?.querySelector('#motion-toggle');if(button){button.setAttribute('aria-pressed',String(paused));button.setAttribute('aria-label',paused?'تشغيل الحركة':'إيقاف الحركة');button.title=paused?'تشغيل الحركة':'إيقاف الحركة';}
 if(!root||!motionEnabled())return;
 gsap.to(uniforms,{shape:shapes[view]??0,duration:1.2,ease:'power2.inOut',overwrite:true});
 context=gsap.context(()=>{
  const heading=root.querySelector('.page-heading h1');
  if(heading)gsap.fromTo(heading,{y:22,filter:'blur(9px)',opacity:.4},{y:0,filter:'blur(0px)',opacity:1,duration:.7,ease:'power3.out',clearProps:'filter,transform,opacity'});
  const entrance=root.querySelectorAll('.page-heading p,.page-heading .actions,.filters,.summary');
  gsap.fromTo(entrance,{y:14,opacity:.5},{y:0,opacity:1,stagger:.045,duration:.55,delay:.08,ease:'power3.out',clearProps:'all'});
  const panels=[...root.querySelectorAll('.panel')];
  observer=new IntersectionObserver(entries=>{for(const e of entries){if(e.isIntersecting){gsap.fromTo(e.target,{y:18,opacity:.6},{y:0,opacity:1,duration:.6,ease:'power3.out',clearProps:'transform,opacity'});observer.unobserve(e.target);}}},{threshold:.04});panels.forEach(p=>observer.observe(p));
  root.querySelectorAll('.bar-track>div').forEach(bar=>gsap.fromTo(bar,{scaleX:0},{scaleX:1,transformOrigin:'right center',duration:.85,ease:'power3.out',scrollTrigger:{trigger:bar,start:'top 95%',once:true}}));
 },root);
}
export async function transitionOut(element){if(!element||!motionEnabled())return;await gsap.to(element,{opacity:.35,y:-9,filter:'blur(4px)',duration:.15,ease:'power2.in'});}
export function setupNavigation(root){
 const toggle=root.querySelector('#menu-toggle'),nav=root.querySelector('#main-navigation');if(!toggle||!nav)return;
 const controller=new AbortController();cleanupListeners=()=>{controller.abort();document.body.classList.remove('menu-open');};
 const close=()=>{document.body.classList.remove('menu-open');toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-label','فتح قائمة التنقل');};
 toggle.addEventListener('click',()=>{const open=!document.body.classList.contains('menu-open');document.body.classList.toggle('menu-open',open);toggle.setAttribute('aria-expanded',String(open));toggle.setAttribute('aria-label',open?'إغلاق قائمة التنقل':'فتح قائمة التنقل');if(open&&motionEnabled())gsap.fromTo(nav.querySelectorAll('button'),{y:20,opacity:.25,filter:'blur(6px)'},{y:0,opacity:1,filter:'blur(0px)',stagger:.045,duration:.5,ease:'power3.out',clearProps:'all'});if(open)nav.querySelector('button')?.focus();},{signal:controller.signal});
 root.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',close,{signal:controller.signal}));
 document.addEventListener('keydown',e=>{if(!document.body.classList.contains('menu-open'))return;if(e.key==='Escape'){close();toggle.focus();}if(e.key==='Tab'){const items=[toggle,...nav.querySelectorAll('button')];const i=items.indexOf(document.activeElement);if(e.shiftKey&&i<=0){e.preventDefault();items.at(-1).focus();}else if(!e.shiftKey&&i===items.length-1){e.preventDefault();toggle.focus();}}},{signal:controller.signal});
 return close;
}
export function animateToast(box){if(motionEnabled())gsap.fromTo(box,{y:-6,opacity:.4},{y:0,opacity:1,duration:.25,ease:'power2.out',clearProps:'all'});}
