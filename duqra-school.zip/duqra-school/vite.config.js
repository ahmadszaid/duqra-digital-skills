import {defineConfig} from 'vite';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
// Development only: the private roster never enters the public build.
const privateRoster=fileURLToPath(new URL('../private-school-data/school-rosters.private.json',import.meta.url));
export default defineConfig({base:'./',build:{target:'es2022'},plugins:[{name:'local-private-roster',apply:'serve',configureServer(server){
 server.middlewares.use('/__private/rosters',async(req,res)=>{const host=(req.headers.host??'').split(':')[0];const origin=req.headers.origin;const sameSite=req.headers['sec-fetch-site'];if(!['127.0.0.1','localhost'].includes(host)||(sameSite&&!['same-origin','none'].includes(sameSite))||(origin&&!['http://'+req.headers.host,'https://'+req.headers.host].includes(origin))){res.statusCode=403;res.end();return;}try{const data=await readFile(privateRoster);res.setHeader('Content-Type','application/json; charset=utf-8');res.setHeader('Cache-Control','no-store');res.end(data);}catch{res.statusCode=404;res.end();}});

}}]});
