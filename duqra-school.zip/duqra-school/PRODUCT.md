# Product — سجلّ

Arabic RTL personal school web app for المعلم أحمد شتيوي at مدرسة دوقرة الثانوية الشاملة للبنين. The only subject is المهارات الرقمية.

User explicitly requested no accounts: open directly into the personal workspace with private IndexedDB persistence and backup/restore. No automatic cross-device sync. The previous Firebase adapter remains inactive legacy source and is lazy-loaded only for its unused legacy branch.

Existing JavaScript/Vite project retained. GSAP3.15 and Canvas provide the user-selected Halcyon Private AI visual language; locally hosted Noto Sans Arabic Variable supports RTL. Grades, reports, imports, audits, export/print and theme settings remain.

236 true student names in ten classes/streams were extracted and visually reviewed from ten PDFs/twelve pages. Their private package remains outside publishable source. Local development may seed an empty store from that file through a localhost-only route. The public build never contains names or grades. QA uses a separate database and fictional students.

Grade distribution: first30; participation5, behavior5, quizzes5, homework5, practical10; final40. Pass50. Missing marks are incomplete and excluded from success rates. Preserve class/term/year filtering, name search, student ranking, class comparison, Excel, PDF printing, manual/PDF/roster import and audit history.

Visual authority: https://animatedwebs.com/templates/halcyon-private-ai — dark atmosphere, particle iris, blur reveals, cinematic transitions, transparent panels, mobile menu. Adapt to the teacher workflow without scroll hijacking or movement while typing marks. Respect reduced-motion preferences and provide pause control.
