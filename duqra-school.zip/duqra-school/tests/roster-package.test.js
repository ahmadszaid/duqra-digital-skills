import {test} from 'node:test';
import assert from 'node:assert/strict';
import {validateRosterPackage} from '../src/roster-package.js';
const example=()=>({schemaVersion:1,subject:'المهارات الرقمية',studentCount:1,classes:[{id:'g09-b',name:'التاسع / ب',students:[{id:'s001',name:'طالب اختبار وهمي',sourceRow:1}]}]});
test('valid private roster accepted',()=>assert.equal(validateRosterPackage(example()).studentCount,1));
test('count mismatch rejected',()=>assert.throws(()=>validateRosterPackage({...example(),studentCount:2})));
test('other subject rejected',()=>assert.throws(()=>validateRosterPackage({...example(),subject:'علوم'})));
test('duplicate class and student identifiers rejected',()=>{const x=example();x.classes.push(x.classes[0]);assert.throws(()=>validateRosterPackage(x));const y=example();y.classes[0].students.push({...y.classes[0].students[0],name:'اسم تجريبي مختلف'});y.studentCount=2;assert.throws(()=>validateRosterPackage(y));});
