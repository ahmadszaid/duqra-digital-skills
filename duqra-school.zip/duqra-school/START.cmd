@echo off
setlocal
cd /d "%~dp0"
set "TASK_RUNTIME=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies"
where node >nul 2>nul
if errorlevel 1 if exist "%TASK_RUNTIME%\node\bin\node.exe" set "PATH=%TASK_RUNTIME%\node\bin;%PATH%"
where node >nul 2>nul
if errorlevel 1 (
 echo Install Node.js 24 and pnpm 11, then run START.cmd again.
 pause
 exit /b 1
)
if not exist node_modules\vite\bin\vite.js (
 where pnpm >nul 2>nul
 if not errorlevel 1 (
  call pnpm install
 ) else if exist "%TASK_RUNTIME%\bin\fallback\pnpm.cmd" (
  call "%TASK_RUNTIME%\bin\fallback\pnpm.cmd" install
 ) else (
  echo Install pnpm 11, then run START.cmd again.
  pause
  exit /b 1
 )
)
echo Open the local address shown below. Press Ctrl+C to stop.
node node_modules\vite\bin\vite.js --host 127.0.0.1 --open
pause
