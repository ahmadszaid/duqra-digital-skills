# Design — سجلّ / Halcyon-inspired personal workspace

## Authority
User selected Halcyon Private AI as the visual and motion reference, then explicitly requested personal use with no accounts. Retain the existing grades, reports, import, audit, settings, export and print functions, all ten real rosters, Arabic RTL, teacher أحمد شتيوي and subject المهارات الرقمية.

## Visual tokens
Dark: background #04060d; surface rgba(255,255,255,.035); solid surface #0c111c; ink #f4f7fb; secondary #a6b2c4; line rgba(215,230,255,.12); cyan #abd9f4; primary #f6f8fc with ink #101a28.
Light: background #eef2f7; surface rgba(255,255,255,.84); ink #14243b; secondary #53657a; line #cbd5e2; blue #235e80.
Typography: locally hosted Noto Sans Arabic Variable, Tahoma fallback. Headings 35–64px at weight 400; body 13px/2; table 12px; quiet labels 10–11px. No negative letter spacing within Arabic names.
Panels 24px desktop / 20px phone, fields 14px, pill buttons. Header blur20px, subtle radial blue/cyan background fields, original animated geometric particle iris behind content.

## Composition
Sticky floating horizontal header, five existing sections in one navigation. Below 950px the same navigation becomes a full-height mobile sheet. Page title and description have generous space, with export controls opposite. Filters, a divided four-part summary, then the existing table or report panels. At 600px filters wrap and summary becomes two columns; only the table scrolls horizontally.

## Motion contract
GSAP 3.15: heading blur9px and y22px resolves in .7s, filter/summary entrance .55s with .045s stagger, panel reveal .6s, route exit .15s, menu stagger .045s. Canvas targets 30fps, max DPR1.5, 2200 particles desktop / 760 on phone; pauses for background tabs, user pause and OS reduced motion. Mouse movement influences particle depth; section changes morph the iris. No motion on edited grade cells. No scroll hijacking.

## Data boundary
Personal IndexedDB storage, no login. Private source roster stays outside the publishable project and is loaded only via the localhost development route when local data is empty. Public build contains no real student names. Backups and restore are local and explicit. QA uses a separate database and fictional students.

## Evidence
Reference inspected across its four routes and section inventories; values read from computed DOM. Desktop and real 390px iframe viewport inspected in the browser. Functional checks use fictional data, including persistence across reload, auditing, comparison, downloads and restore. See TEST-RESULTS.md for exact scope.
